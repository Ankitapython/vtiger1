from setuptools import setup, find_packages

setup(
    name='vtiger1',
    version='1.0',
    packages=find_packages(include=['source'])
)